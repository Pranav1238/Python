from django.shortcuts import render,redirect
from django.views import View
from django.views.generic import TemplateView
import hashlib
from .models import AllUrl
from django.views.generic import (
	ListView,
)
from django.shortcuts import get_object_or_404

# Create your views here.
class Home(View):
    def get(self,request,*args,**kwargs):
        context={
            'ShortUrl': ''
        }
        return render(request,"Shorter/home.html",context)
    
    def post(self,request,*args,**kwargs):
        url=request.POST['userurl']
        
        hashObject = hashlib.md5(url.encode('utf-8'))
        shorturl = hashObject.hexdigest()[:8]    
        context={
            'ShortUrl': shorturl
        }
        if not AllUrl.objects.filter(Main_url=url).exists() :
            to_save=AllUrl(Main_url=url,Short_Url=shorturl)
            to_save.save()
        return render(request,"Shorter/home.html",context)

class PersonListView(ListView):
	model = AllUrl


def Detail(request,urlname):
    single_url=get_object_or_404(AllUrl,Short_Url=urlname)
    Main=single_url.Main_url
    return redirect(Main)
