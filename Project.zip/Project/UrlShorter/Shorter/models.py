from django.db import models
from django.utils import timezone
from datetime import datetime 
# Create your models here.

class AllUrl(models.Model):
    Main_url=models.CharField(max_length=500)
    Short_Url=models.CharField(max_length=20)
    Created_Date = models.DateField(default=timezone.now())
    Created_time = models.TimeField(default=datetime.now())
