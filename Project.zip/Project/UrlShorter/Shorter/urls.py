from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.Home.as_view(),name="Home"),
    path('AllShort/',views.PersonListView.as_view(),name="allurl"),
    path('Short/<str:urlname>/',views.Detail,name="allurl"),
]