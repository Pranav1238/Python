from django.apps import AppConfig


class ShorterConfig(AppConfig):
    name = 'Shorter'
